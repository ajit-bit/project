// app.js
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// PostgreSQL configuration
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'pms',
    password: '123456',
    port: 5432,
});

// Check if user with given ID exists in the database
async function userExists(id) {
    const queryText = 'SELECT id FROM employee_data WHERE id = $1';
    const result = await pool.query(queryText, [id]);
    return result.rows.length > 0;
}
// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Retrieve data by ID
app.get('/retrieve', async (req, res) => {
    const id = req.query.id;
    try {
      const result = await pool.query('SELECT * FROM employee_data WHERE id = $1', [id]);
      if (result.rows.length > 0) {
        res.json(result.rows[0]);
      } else {
        res.status(404).send('Data not found');
      }
    } catch (err) {
      res.status(500).send('Server error');
    }
  });

// Add or update user
app.post('/users', async (req, res) => {
    const { name, dept, present_address, permanent_address
        , email, mobile_no, highest_qualification, additional_qualifications
        , pursuing_degree_certification, dob_dd, dob_MM, dob_YYYY
        , age_months, age_years, years_of_service, doj_college,
        doj_svu, date_last_promotion, Presentbasic_level, Presentbasic_cell_no,
        Presentbasic_june_year, Presentbasic_jan_year, Presentbasic_amount,
        teaching_experience_years, industry_experience_years, total_experience_years } = req.body;
    let id = name + "_" + dept;
    const idExists = await userExists(id);
    if (idExists) {
        // Update existing user if ID exists in the database
        const queryText = `UPDATE employee_data SET name = $1, dept = $2, present_address = $3, permanent_address = $4, 
        email = $5, mobile_no = $6, highest_qualification = $7, additional_qualifications = $8, pursuing_degree_certification = $9, 
        dob_dd = $10, dob_MM = $11, dob_YYYY = $12, age_months = $13, age_years = $14, years_of_service = $15, 
        doj_college = $16, doj_svu = $17, date_last_promotion = $18, Presentbasic_level = $19, 
        Presentbasic_cell_no = $20, Presentbasic_june_year = $21, Presentbasic_jan_year = $22, Presentbasic_amount = $23, 
        teaching_experience_years = $24, industry_experience_years = $25, total_experience_years = $26 WHERE id = $27`;
        ;
        try {
            await pool.query(queryText, [name, dept, present_address, permanent_address
                , email, mobile_no, highest_qualification, additional_qualifications
                , pursuing_degree_certification, dob_dd, dob_MM, dob_YYYY
                , age_months, age_years, years_of_service, doj_college,
                doj_svu, date_last_promotion, Presentbasic_level, Presentbasic_cell_no,
                Presentbasic_june_year, Presentbasic_jan_year, Presentbasic_amount,
                teaching_experience_years, industry_experience_years, total_experience_years, id]);
                res.send({ success: true, message: 'User added successfully!' }); // Send success message as JSON
            } catch (err) {
                console.error('Error executing query', err);
                res.status(500).send({ success: false, error: 'Error adding user' }); // Send error message as JSON
            }
    } else {
        // Insert new user if ID does not exist in the database
        const queryText = `INSERT INTO employee_data (id, name, dept, present_address, permanent_address
        ,email, mobile_no, highest_qualification, additional_qualifications
        , pursuing_degree_certification, dob_dd, dob_MM, dob_YYYY, age_months, age_years
        , years_of_service, doj_college,doj_svu ,date_last_promotion, Presentbasic_level, Presentbasic_cell_no,
        Presentbasic_june_year, Presentbasic_jan_year, Presentbasic_amount, teaching_experience_years
        , industry_experience_years, total_experience_years) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,
        $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27);`;
        try {
            await pool.query(queryText, [id, name, dept, present_address, permanent_address
                , email, mobile_no, highest_qualification, additional_qualifications
                , pursuing_degree_certification, dob_dd, dob_MM, dob_YYYY
                , age_months, age_years, years_of_service, doj_college,
                doj_svu, date_last_promotion, Presentbasic_level, Presentbasic_cell_no,
                Presentbasic_june_year, Presentbasic_jan_year, Presentbasic_amount,
                teaching_experience_years, industry_experience_years, total_experience_years]);
                res.send({ success: true, message: 'User updated successfully!' }); // Send success message as JSON
            } catch (err) {
                console.error('Error executing query', err);
                res.status(500).send({ success: false, error: 'Error updating user' }); // Send error message as JSON
            }
    }
});

// Delete user
app.delete('/users/:id', async (req, res) => {
    const id = req.params.id;
    const queryText = 'DELETE FROM employee_data WHERE id = $1';
    try {
      await pool.query(queryText, [id]);
      res.send('User deleted successfully!');
    } catch (err) {
      console.error('Error executing query', err);
      res.status(500).send('Error deleting user');
    }
  });

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
