function Update_1A(input) {
  let row = input.parentNode.parentNode;
  function calculatePercentage(assigned, engaged) {
    return (Number(engaged) / Number(assigned)) * 100;
  }
  function updateCellContent(cell, value) {
    cell.querySelector("span").textContent = isNaN(value)
      ? "0.00"
      : value.toFixed(2);
  }
  let assigned = row.cells[1].querySelector("input").value;
  let engaged = row.cells[2].querySelector("input").value;
  let percentage = calculatePercentage(assigned, engaged);
  updateCellContent(row.cells[3], percentage);
  let feedback = percentage / 10;
  updateCellContent(row.cells[4], feedback);
  let table = document.getElementById("Q_1A");
  function calculateAverageAndUpdate(selector, resultElementId, scaleFactor) {
    let total = 0;
    let rowCount = 0;
    for (let i = 1; i < table.rows.length - 1; i++) {
      let value = Number(
        table.rows[i].cells[selector].querySelector("span").textContent
      );
      if (value > 0) rowCount += 1;
      total += value;
    }
    let average = total / rowCount;
    let scaledResult = average * scaleFactor;
    document.getElementById(resultElementId).innerText = isNaN(scaledResult)
      ? "0.00"
      : scaledResult.toFixed(2);
  }
  calculateAverageAndUpdate(3, "Ans_1A", 0.4);
  calculateAverageAndUpdate(4, "Ans_1B", 3);
  FinalAdd();
}
function AddRow_1A() {
  if (COUNT["Q_1A"] % 2 == 0) {
    let table = document.getElementById("Q_1A");
    let newRow = table.insertRow(table.rows.length - 1);
    newRow.innerHTML = `
      <td><input type="text"></td>
      <td><input type="number" oninput="Update_1A(this)"></td>
      <td><input type="number" oninput="Update_1A(this)"></td>
      <td><span></span></td>
      <td><span></span></td>`;
  } else {
    let table = document.getElementById("Q_1A");
    let newRow = table.insertRow(table.rows.length - 1);
    newRow.innerHTML = `
      <td><input type="text"></td>
      <td><input type="number" oninput="Update_1A(this)"></td>
      <td><input type="number" oninput="Update_1A(this)"></td>
      <td><span></span></td>
      <td><span></span></td>
      <td style="border: none; padding-left: 10px;"> <button onclick="REMOVEROW(this, ' Q_1A')">Remove</button></td>`;
  }
}
function Update_1D() {
  let table = document.getElementById("Q_1D");
  let total = 0;
  for (let i = 1; i < table.rows.length - 1; i++) {
    let row = table.rows[i];
    if (row.cells.length === 3 && row.cells[2].rowSpan === 2) {
      let marks1 = row.cells[2].querySelector("input").value;
      total += Number(marks1);
    } else if (row.cells.length === 3) {
      let marks2 = row.cells[2].querySelector("input").value;
      total += Number(marks2);
    }
  }
  if (total > 50) {
    total = 50;
  }
  document.getElementById("Ans_1D").innerText = total;
  FinalAdd();
}
COUNT = {
  Q_1A: 0,
  Q_1C: 0,
  Q_2B: 0,
  Q_2C: 0,
  Q_2D: 0,
  Q_2E: 0,
  Q_2F: 0,
  Q_2G: 0,
  Q_2H: 0,
  Q_2I: 0,
  Q_3A: 0,
  Q_3B: 0,
  Q_3C: 0,
  Q_3D: 0,
  Q_3E: 0,
  Q_4A: 0,
}; // remove button count
function UPDATE(Q, ANS, START, COLUMN, MAX = Infinity) {
  const table = document.getElementById(Q);
  let total = 0;
  for (let i = START; i < table.rows.length - 1; i++) {
    const marks = table.rows[i].cells[COLUMN - 1].querySelector("input").value;
    total += Number(marks);
  }
  if (total > MAX) {
    total = MAX;
  }
  document.getElementById(ANS).innerText = total;
  FinalAdd();
}
function ADDROW(Q, ANS, START, COLUMN, N, MAX = Infinity) {
  if (COUNT[Q] % 2 == 0) {
    if (N === 3) {
      const table = document.getElementById(Q);
      const row = table.insertRow(table.rows.length - 1);
      row.innerHTML = `
      <td><input type="text"></td>
      <td><input type="text"></td>
      <td><input type="number" oninput="UPDATE('${Q}', '${ANS}', ${START}, ${COLUMN}, ${MAX})"></td>`; // without remove button
    } else if (N === 2) {
      const table = document.getElementById(Q);
      const row = table.insertRow(table.rows.length - 1);
      row.innerHTML = `
      <td><input type="text"></td>
      <td><input type="number" oninput="UPDATE('${Q}', '${ANS}', ${START}, ${COLUMN}, ${MAX})"></td>`; // without remove button
    }
  } else {
    if (N === 3) {
      const table = document.getElementById(Q);
      const row = table.insertRow(table.rows.length - 1);
      row.innerHTML = `
      <td><input type="text"></td>
      <td><input type="text"></td>
      <td><input type="number" oninput="UPDATE('${Q}', '${ANS}', ${START}, ${COLUMN}, ${MAX})"></td>
      <td style="border: none; padding-left: 10px;"> <button onclick="REMOVEROW(this, '${Q}')">Remove</button></td>`; // with remove button
    } else if (N === 2) {
      const table = document.getElementById(Q);
      const row = table.insertRow(table.rows.length - 1);
      row.innerHTML = `
      <td><input type="text"></td>
      <td><input type="number" oninput="UPDATE('${Q}', '${ANS}', ${START}, ${COLUMN}, ${MAX})"></td>
      <td style="border: none; padding-left: 10px;"> <button onclick="REMOVEROW(this, '${Q}')">Remove</button></td>`; // with remove button
    }
  }
}
function REMOVE_BUTTON(Q) {
  COUNT[Q]++;
  if (COUNT[Q] % 2 !== 0) {
    const table = document.getElementById(Q);
    array = ["Q_1A", "Q_1C", "Q_3B", "Q_3C", "Q_3D", "Q_3E", "Q_4A"];
    if (array.includes(Q)) {
      for (let i = 0; i < table.rows.length; i++) {
        const newCell = table.rows[i].insertCell(-1);
        if (i === 0 || i === table.rows.length - 1) {
          newCell.innerHTML = " ";
          newCell.setAttribute("style", `border: none;padding-left: 10px'`);
        } else {
          newCell.setAttribute("style", `border: none;padding-left: 10px;`);
          newCell.innerHTML =
            "<button onclick=\"REMOVEROW(this,'" + Q + "')\">Remove</button>";
        }
      }
    } else {
      for (let i = 0; i < table.rows.length; i++) {
        const newCell = table.rows[i].insertCell(-1);
        if (i === 0 || i == 1 || i === table.rows.length - 1) {
          newCell.innerHTML = " ";
          newCell.setAttribute("style", `border: none; padding-left: 10px;`);
        } else {
          newCell.setAttribute("style", `border: none; padding-left: 10px;`);
          newCell.innerHTML =
            "<button onclick=\"REMOVEROW(this,'" + Q + "')\">Remove</button>";
        }
      }
    } // add column
  } else {
    var table = document.getElementById(Q);
    for (var i = 0; i < table.rows.length; i++) {
      var row = table.rows[i];
      if (row.cells.length > 0) {
        row.deleteCell(-1);
      }
    }
  } // remove last column
}
function REMOVEROW(button, Q) {
  const row = button.parentNode.parentNode;
  row.parentNode.removeChild(row); // remove row
  COUNT[Q]++;
  if (Q == "Q_1A") {
    Update_1A(button);
  } else if (Q == "Q_1C") {
    UPDATE("Q_1C", "ANS_1C", 1, 3, 30);
  } else if (Q == "Q_2B") {
    UPDATE("Q_2B", "ANS_2B", 2, 3);
  } else if (Q == "Q_2C") {
    UPDATE("Q_2C", "ANS_2C", 2, 3);
  } else if (Q == "Q_2D") {
    UPDATE("Q_2D", "ANS_2D", 2, 3);
  } else if (Q == "Q_2E") {
    UPDATE("Q_2E", "ANS_2E", 2, 3);
  } else if (Q == "Q_2F") {
    UPDATE("Q_2F", "ANS_2F", 2, 3);
  } else if (Q == "Q_2G") {
    UPDATE("Q_2G", "ANS_2G", 2, 3);
  } else if (Q == "Q_2H") {
    UPDATE("Q_2H", "ANS_2H", 2, 2);
  } else if (Q == "Q_2I") {
    UPDATE("Q_2I", "ANS_2I", 2, 3);
  } else if (Q == "Q_3A") {
    UPDATE("Q_3A", "ANS_3A", 2, 2, 30);
  } else if (Q == "Q_3B") {
    UPDATE("Q_3B", "ANS_3B", 1, 2, 30);
  } else if (Q == "Q_3C") {
    UPDATE("Q_3C", "ANS_3C", 1, 2, 30);
  } else if (Q == "Q_3D") {
    UPDATE("Q_3D", "ANS_3D", 1, 2, 50);
  } else if (Q == "Q_3E") {
    UPDATE("Q_3E", "ANS_3E", 1, 2, 10);
  } else if (Q == "Q_4A") {
    UPDATE("Q_4A", "ANS_4A", 1, 2, 50);
  } // update after removing
  var table = document.getElementById(Q);
  for (var i = 0; i < table.rows.length; i++) {
    var rowx = table.rows[i];
    if (rowx.cells.length > 0) {
      rowx.deleteCell(-1);
    }
  } // rmove last row
}

function FinalAdd() {
  let Ans_1A = document.getElementById("Ans_1A").innerText;
  let Ans_1B = document.getElementById("Ans_1B").innerText;
  let Ans_1C = document.getElementById("ANS_1C").innerText;
  let Ans_1D = document.getElementById("Ans_1D").innerText;
  let ANS_Q1 =
    Number(Ans_1A) + Number(Ans_1B) + Number(Ans_1C) + Number(Ans_1D);
  document.getElementById("ANS_Q1").innerText = ANS_Q1;

  let ANS_2B = document.getElementById("ANS_2B").innerText;
  let ANS_2C = document.getElementById("ANS_2C").innerText;
  let ANS_2D = document.getElementById("ANS_2D").innerText;
  let ANS_2E = document.getElementById("ANS_2E").innerText;
  let ANS_2F = document.getElementById("ANS_2F").innerText;
  let ANS_2G = document.getElementById("ANS_2G").innerText;
  let ANS_2H = document.getElementById("ANS_2H").innerText;
  let ANS_2I = document.getElementById("ANS_2I").innerText;
  let ANS_2J = document.getElementById("ANS_2J").innerText;
  let ANS_Q2 =
    Number(ANS_2B) +
    Number(ANS_2C) +
    Number(ANS_2D) +
    Number(ANS_2E) +
    Number(ANS_2F) +
    Number(ANS_2G) +
    Number(ANS_2H) +
    Number(ANS_2I) +
    Number(ANS_2J);
  document.getElementById("ANS_Q2").innerText = ANS_Q2;

  let ANS_3A = document.getElementById("ANS_3A").innerText;
  let ANS_3B = document.getElementById("ANS_3B").innerText;
  let ANS_3C = document.getElementById("ANS_3C").innerText;
  let ANS_3D = document.getElementById("ANS_3D").innerText;
  let ANS_3E = document.getElementById("ANS_3E").innerText;
  let ANS_Q3 =
    Number(ANS_3A) +
    Number(ANS_3B) +
    Number(ANS_3C) +
    Number(ANS_3D) +
    Number(ANS_3E);
  document.getElementById("ANS_Q3").innerText = ANS_Q3;

  let ANS_Q4 = document.getElementById("ANS_4A").innerText;
  document.getElementById("ANS_Q4").innerText = ANS_Q4;

  let FINAL_500 =
    Number(ANS_Q1) + Number(ANS_Q2) + Number(ANS_Q3) + Number(ANS_Q4);
  document.getElementById("FINAL_500").innerText = FINAL_500;

  let FINAL_10 = FINAL_500 / 50;
  document.getElementById("FINAL_10").innerText = FINAL_10;
}
function UPDATE_D_FINAL() {
  let table = document.getElementById("D_FINAL");
  let FINAL_500 = 0;
  for (let i = 1; i < table.rows.length - 3; i++) {
    let marks = table.rows[i].cells[2].querySelector("input").value;
    FINAL_500 += Number(marks);
  }
  document.getElementById("D_FINAL_500").innerText = FINAL_500;
  let FINAL_10 = FINAL_500 / 50;
  document.getElementById("D_FINAL_10").innerText = FINAL_10;
}
function UPDATE_C_FINAL() {
  let table = document.getElementById("C_FINAL");
  let FINAL_500 = 0;
  for (let i = 1; i < table.rows.length - 3; i++) {
    let marks = table.rows[i].cells[2].querySelector("input").value;
    FINAL_500 += Number(marks);
  }
  document.getElementById("C_FINAL_500").innerText = FINAL_500;
  let FINAL_10 = FINAL_500 / 50;
  document.getElementById("C_FINAL_10").innerText = FINAL_10;
}

function expandInput(event) {
  const textarea = event.target;
  textarea.style.height = "auto";
  textarea.style.height = textarea.scrollHeight + "px";
}
const inputField = document.querySelector(".expandable-input");
inputField.addEventListener("input", expandInput);

async function loadUser() {
  const id = document.getElementById('id').value;
  const response = await fetch(`/retrieve?id=${id}`);
  if (response.ok) {
    const data = await response.json();
    console.log('Data retrieved from server:', data);
    document.getElementById('name').value = data.name;
    document.getElementById('dept').value = data.dept;
    document.getElementById('present_address').value = data.present_address;
    document.getElementById('permanent_address').value = data.permanent_address;
    document.getElementById('email').value = data.email;
    document.getElementById('mobile_no').value = data.mobile_no;
    document.getElementById('highest_qualification').value = data.highest_qualification;
    document.getElementById('additional_qualifications').value = data.additional_qualifications;
    document.getElementById('pursuing_degree_certification').value = data.pursuing_degree_certification;
    document.getElementById('dob_dd').value = data.dob_dd;
    document.getElementById('dob_MM').value = data.dob_mm;
    document.getElementById('dob_YYYY').value = data.dob_yyyy;
    document.getElementById('age_months').value = data.age_months;
    document.getElementById('age_years').value = data.age_years;
    document.getElementById('years_of_service').value = data.years_of_service;
    document.getElementById('doj_college').value = data.doj_college;
    document.getElementById('doj_svu').value = data.doj_svu;
    document.getElementById('date_last_promotion').value = data.date_last_promotion;
    document.getElementById('Presentbasic_level').value = data.presentbasic_level;    ;
    document.getElementById('Presentbasic_cell_no').value = data.presentbasic_cell_no;
    document.getElementById('Presentbasic_june_year').value = data.presentbasic_june_year;
    document.getElementById('Presentbasic_jan_year').value = data.presentbasic_jan_year;
    document.getElementById('Presentbasic_amount').value = data.presentbasic_amount;
    document.getElementById('teaching_experience_years').value = data.teaching_experience_years;
    document.getElementById('industry_experience_years').value = data.industry_experience_years;
    document.getElementById('total_experience_years').value = data.total_experience_years;
    alert('Data Found');
  } else {
    alert('Data not found');
  }
  document.getElementById('id').value = ''
  Load_Form();
}
function updateuser() {
  const form = document.getElementById('updateForm');
  const formData = new FormData(form); // Correctly reference the form
  const userData = Object.fromEntries(formData.entries()); // Convert form data to JSON object

  fetch('/users', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData) // Send user data as JSON
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert(data.message); // Display success message as alert
      } else {
        alert(data.error); // Display error message as alert
      }
    })
    .catch(error => {
      console.error('Error:', error);
      alert('Error adding/updating user!');
    });
}
// Function to delete user via AJAX
function deleteUser() {
  const formData = new FormData(document.getElementById('deleteForm'));
  fetch(`/users/${formData.get('id')}`, {
    method: 'DELETE'
  }).then(response => {
    if (response.ok) {
      alert('User deleted successfully!');
    } else {
      alert('Error deleting user!');
    }
  }).catch(error => {
    console.error('Error:', error);
    alert('Error deleting user!');
  });
  document.getElementById('deleteId').value = ''
  Delete_Form();
}

function Load_Form() {
  const d = document.getElementById('deleteForm');
  d.style.display = 'none';
  const l = document.getElementById('loadForm');
  if (l.style.display === 'none') {
    l.style.display = 'block';
  } else {
    l.style.display = 'none';
  }
}
function Delete_Form() {
  const d = document.getElementById('deleteForm');
  const l = document.getElementById('loadForm');
  l.style.display = 'none';
  if (d.style.display === 'none') {
    d.style.display = 'block';
  } else {
    d.style.display = 'none';
  }
}





